export { registerObjectStorageRoutes } from "./routes";
